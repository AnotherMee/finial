package Replica2;


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import javax.xml.ws.Endpoint;


import Entity.Event;
import Entity.LoggerFile;

public class MontrealServer {

	public static MontrealObj Mon;


	public static void main(String args[]) {
		Mon = new MontrealObj();
		
		Runnable task = () -> {
			UdpConnection();
		};
		Runnable task2 = () -> {
				server();
		};

		Thread thread = new Thread(task);
		Thread thread2 = new Thread(task2);

		thread.start();
		thread2.start();

	}

	public static void UdpConnection() {
		System.out.println("MONTREAL UDP SERVER STARTED ON " + 8886);
		LoggerFile log = new LoggerFile();
		log.logger.setLevel(Level.INFO);
		log.logger.info("MONTREAL UDP SERVER STARTED ON" + 8886);
		try {
			while (true) {
				DatagramSocket mySocket = new DatagramSocket(8886);
				DatagramPacket reply;
				// instantiates a datagram socket for receiving the data
				byte[] buffer = new byte[1000];
				DatagramPacket datagram = new DatagramPacket(buffer, buffer.length);
				mySocket.receive(datagram);
				String message = (new String(datagram.getData()).trim());
				System.out.println("message " + message);
				log.logger.setLevel(Level.INFO);
				log.logger.info("Montreal server received request " + message + " from the server with port "
						+ datagram.getPort());
				String replycon = "";
				if (message.contains(",")) {
					String customerId = message.split(",")[0];
					String eventId = message.split(",")[1];
					String eventType = message.split(",")[2];
					int check = Mon.findEvent(customerId, eventId);
					if (eventType.equalsIgnoreCase("conference")) {
						if (Mon.conferenceList.containsKey(eventId.toUpperCase())) {
							if (Mon.conferenceList.get(eventId.toUpperCase()) >= 1) {
								if (Mon.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = Mon.conferenceList.get(eventId.toUpperCase());
									caps -= 1;
									Mon.conferenceList.put(eventId.toUpperCase(), caps);
									Mon.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!Mon.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = Mon.conferenceList.get(eventId.toUpperCase());
									caps -= 1;
									Mon.conferenceList.put(eventId.toUpperCase(), caps);
									List<Event> add = new ArrayList<Event>();
									Mon.eventBook.put(customerId, add);
									Mon.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					} else if (eventType.equalsIgnoreCase("seminar")) {
						if (Mon.seminalList.containsKey(eventId.toUpperCase())) {
							if (Mon.seminalList.get(eventId.toUpperCase()) >= 1) {
								if (Mon.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = Mon.seminalList.get(eventId.toUpperCase());
									caps -= 1;
									Mon.seminalList.put(eventId.toUpperCase(), caps);
									Mon.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!Mon.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = Mon.seminalList.get(eventId.toUpperCase());
									caps -= 1;
									Mon.seminalList.put(eventId.toUpperCase(), caps);
									List<Event> add = new ArrayList<Event>();
									Mon.eventBook.put(customerId, add);
									Mon.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						if (Mon.tradeshowList.containsKey(eventId.toUpperCase())) {
							if (Mon.tradeshowList.get(eventId.toUpperCase()) >= 1) {
								if (Mon.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = Mon.tradeshowList.get(eventId.toUpperCase());
									caps -= 1;
									Mon.tradeshowList.put(eventId.toUpperCase(), caps);
									Mon.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!Mon.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = Mon.tradeshowList.get(eventId.toUpperCase());
									caps -= 1;
									Mon.tradeshowList.put(eventId, caps);
									List<Event> add = new ArrayList<Event>();
									Mon.eventBook.put(customerId, add);
									Mon.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					}

					System.out.println("replycon " + replycon);
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					log.logger.setLevel(Level.INFO);
					log.logger.info("Montreal Server sending back response " + replycon + "to Server with port "
							+ reply.getPort());
					mySocket.send(reply);
				}

				if (message.contains(":")) {
					String customerId = message.split(":")[0];
					String eventId = message.split(":")[1];
					String eventType = message.split(":")[2];
					int check = Mon.findEvent(customerId, eventId);
					if (eventType.equalsIgnoreCase("conference")) {
						if (Mon.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = Mon.findEvent(customerId, eventId);
							Mon.eventBook.get(customerId).remove(index);
							Mon.conferenceList.put(eventId.toUpperCase(),
									Mon.conferenceList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
									+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					} else if (eventType.equalsIgnoreCase("seminar")) {
						if (Mon.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = Mon.findEvent(customerId, eventId);
							Mon.eventBook.get(customerId).remove(index);
							Mon.seminalList.put(eventId.toUpperCase(), Mon.seminalList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
									+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						if (Mon.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = Mon.findEvent(customerId, eventId);
							Mon.eventBook.get(customerId).remove(index);
							Mon.tradeshowList.put(eventId.toUpperCase(),
									Mon.tradeshowList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
									+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					log.logger.setLevel(Level.INFO);
					log.logger.info("Montreal Server sending back response " + replycon + "to Server with port "
							+ reply.getPort());
					mySocket.send(reply);

				}
				if (message.contains("Swap")) {
					String customerId = message.split(" ")[1];
					String newEventId = message.split(" ")[2];
					String newEventType = message.split(" ")[3];
					String oldEventId = message.split(" ")[4];
					String oldEventType = message.split(" ")[5];
					int check = Mon.findEvent(customerId, oldEventId);
					if (Mon.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
					replycon = Mon.bookEvent(customerId, newEventId, newEventType);	
					if(replycon.contains("Your")) {
					Mon.eventBook.get(customerId).remove(check);
					Mon.eventList.get(oldEventType.toUpperCase()).put(oldEventId.toUpperCase(), Mon.eventList.get(oldEventType.toUpperCase()).get(oldEventId.toUpperCase()) + 1);
					}
					}else {
						replycon = "false";
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				if (message.contains("L-")) {
					String eventType = message.split("-")[1];
					String s = MontrealServer.sendRequest(8888, "L-" + eventType);
					if (eventType.equalsIgnoreCase("conference")) {
						replycon = Mon.conferenceList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("seminar")) {
						replycon = Mon.seminalList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						replycon = Mon.tradeshowList.toString();
						System.out.println("List: "+replycon.toString());
					} else {
						replycon = "false";
					}
					replycon = replycon+" "+s;
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				if (message.contains("X-")) {
					String eventType = message.split("-")[1];
					String s = MontrealServer.sendRequest(8887, "X-" + eventType);
					if (eventType.equalsIgnoreCase("conference")) {
						replycon = Mon.conferenceList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("seminar")) {
						replycon = Mon.seminalList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						replycon = Mon.tradeshowList.toString();
						System.out.println("List: "+replycon.toString());
					} else {
						replycon = "false";
					}
					replycon = replycon+" "+s;
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				if(message.contains("V")) {
					replycon = "";
					String customerId = message.split(" ")[1];
					String s = MontrealServer.sendRequest(8888, "V " + customerId);
					if (Mon.eventBook.containsKey(customerId)) {
						for (int i = 0; i < Mon.eventBook.get(customerId).size(); i++) {
							replycon += Mon.eventBook.get(customerId).get(i).getEventId() + " "
									+ Mon.eventBook.get(customerId).get(i).getEventType() + "\n";
						}
					}else {
						replycon = "";
					}
					replycon = replycon+s;
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}	
				if(message.contains("P")) {
					replycon = "";
					String customerId = message.split(" ")[1];
					String s = MontrealServer.sendRequest(8887, "P " + customerId);
					if (Mon.eventBook.containsKey(customerId)) {
						for (int i = 0; i < Mon.eventBook.get(customerId).size(); i++) {
							replycon += Mon.eventBook.get(customerId).get(i).getEventId() + " "
									+ Mon.eventBook.get(customerId).get(i).getEventType() + "\n";
						}
					}else {
						replycon = "";
					}
					replycon = replycon+s;
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				mySocket.close();
			}
		} // end try
		catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public static void server() {
		LoggerFile log = new LoggerFile();
		Endpoint.publish("http://localhost:8080/montreal", Mon);
		System.out.println("MONTREAL Server is Up & Running");
		log.logger.setLevel(Level.INFO);
		log.logger.info("MONTREAL Server is Up & Running");
	}

	public static String sendRequest(int port, String requests) {
		LoggerFile log = new LoggerFile();
		log.logger.setLevel(Level.INFO);
		DatagramSocket aSocket = null;
		String res = "";
		try {
			aSocket = new DatagramSocket();
			InetAddress aHost = InetAddress.getByName("localhost");
			String req_msg = requests;
			byte[] message = new byte[1000];
			message = req_msg.trim().getBytes();
			System.out.println("request " + message);
			DatagramPacket request = new DatagramPacket(message, message.length, aHost, port);
			log.logger.info("Montreal Server sending this request " + message + " to server with port " + port);
			aSocket.send(request);
			byte[] buffer = new byte[1000];
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
			aSocket.receive(reply);
			res = new String(reply.getData());
		} catch (Exception e) {
			System.out.println("Socket: " + e.getMessage());
		}
		return res;
	}

}
