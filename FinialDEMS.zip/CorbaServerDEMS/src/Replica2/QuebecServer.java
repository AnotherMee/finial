package Replica2;


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import javax.xml.ws.Endpoint;

import Entity.Event;
import Entity.LoggerFile;

public class QuebecServer {

	public static QuebecObj Que;

	public static void main(String args[]){
		Que = new QuebecObj();
		Runnable task = () -> {
			UdpConnection();
		};
		Runnable task2 = () -> {
		
				server();
		};

		Thread thread = new Thread(task);
		Thread thread2 = new Thread(task2);

		thread.start();
		thread2.start();

	}

	public static void UdpConnection() {
		LoggerFile log = new LoggerFile();
		System.out.println("QUEBEC UDP SERVER STARTED ON " + 8887);
		log.logger.setLevel(Level.INFO);
		log.logger.info("QUEBEC UDP SERVER STARTED ON " + 8887);
		try {
			while (true) {
				DatagramSocket mySocket = new DatagramSocket(8887);
				DatagramPacket reply;

				// instantiates a datagram socket for receiving the data
				byte[] buffer = new byte[1000];
				DatagramPacket datagram = new DatagramPacket(buffer, buffer.length);
				mySocket.receive(datagram);
				String message = (new String(datagram.getData()).trim());
				System.out.println("message " + message);
				log.logger.setLevel(Level.INFO);
				log.logger.info("Quebec server received request "+message+ " from the server with port "+datagram.getPort());
				String replycon = "";
				if (message.contains(",")) {
					String customerId = message.split(",")[0];
					String eventId = message.split(",")[1];
					String eventType = message.split(",")[2];
					int check = Que.findEvent(customerId, eventId);
					if (eventType.equalsIgnoreCase("conference")) {
						if (Que.conferenceList.containsKey(eventId.toUpperCase())) {
							if (Que.conferenceList.get(eventId.toUpperCase()) >= 1) {
								if (Que.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = Que.conferenceList.get(eventId.toUpperCase());
									caps -= 1;
									Que.conferenceList.put(eventId.toUpperCase(), caps);
									Que.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!Que.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = Que.conferenceList.get(eventId.toUpperCase());
									caps -= 1;
									Que.conferenceList.put(eventId.toUpperCase(), caps);
									List<Event> add = new ArrayList<Event>();
									Que.eventBook.put(customerId, add);
									Que.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					} else if (eventType.equalsIgnoreCase("seminar")) {
						if (Que.seminalList.containsKey(eventId.toUpperCase())) {
							if (Que.seminalList.get(eventId.toUpperCase()) >= 1) {
								if (Que.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = Que.seminalList.get(eventId.toUpperCase());
									caps -= 1;
									Que.seminalList.put(eventId.toUpperCase(), caps);
									Que.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!Que.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = Que.seminalList.get(eventId.toUpperCase());
									caps -= 1;
									Que.seminalList.put(eventId.toUpperCase(), caps);
									List<Event> add = new ArrayList<Event>();
									Que.eventBook.put(customerId, add);
									Que.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());

								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						if (Que.tradeshowList.containsKey(eventId.toUpperCase())) {
							if (Que.tradeshowList.get(eventId.toUpperCase()) >= 1) {
								if (Que.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = Que.tradeshowList.get(eventId.toUpperCase());
									caps -= 1;
									Que.tradeshowList.put(eventId.toUpperCase(), caps);
									Que.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!Que.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = Que.tradeshowList.get(eventId.toUpperCase());
									caps -= 1;
									Que.tradeshowList.put(eventId, caps);
									List<Event> add = new ArrayList<Event>();
									Que.eventBook.put(customerId, add);
									Que.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					}

					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					log.logger.setLevel(Level.INFO);
					log.logger.info("Quebec Server sending back response "+replycon+ "to Server with port "+ reply.getPort());
					mySocket.send(reply);
				}
				if (message.contains(":")) {
					String customerId = message.split(":")[0];
					String eventId = message.split(":")[1];
					String eventType = message.split(":")[2];
					int check = Que.findEvent(customerId, eventId);
					if (eventType.equalsIgnoreCase("conference")) {
						if (Que.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = Que.findEvent(customerId, eventId);
							Que.eventBook.get(customerId).remove(index);
							Que.conferenceList.put(eventId.toUpperCase(),
									Que.conferenceList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
							+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					} else if (eventType.equalsIgnoreCase("seminar")) {
						if (Que.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = Que.findEvent(customerId, eventId);
							Que.eventBook.get(customerId).remove(index);
							Que.seminalList.put(eventId.toUpperCase(), Que.seminalList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
							+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						if (Que.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = Que.findEvent(customerId, eventId);
							Que.eventBook.get(customerId).remove(index);
							Que.tradeshowList.put(eventId.toUpperCase(),
									Que.tradeshowList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
							+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					log.logger.setLevel(Level.INFO);
					log.logger.info("Quebec Server sending back response "+replycon+ "to Server with port "+ reply.getPort());
					mySocket.send(reply);

				}
				if (message.contains("Swap")) {
					String customerId = message.split(" ")[1];
					String newEventId = message.split(" ")[2];
					String newEventType = message.split(" ")[3];
					String oldEventId = message.split(" ")[4];
					String oldEventType = message.split(" ")[5];
					int check = Que.findEvent(customerId, oldEventId);
					if (Que.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
					replycon = Que.bookEvent(customerId, newEventId, newEventType);	
					if(replycon.contains("Your")) {
					Que.eventBook.get(customerId).remove(check);
					Que.eventList.get(oldEventType.toUpperCase()).put(oldEventId.toUpperCase(), Que.eventList.get(oldEventType.toUpperCase()).get(oldEventId.toUpperCase()) + 1);
					}
					}else {
						replycon = "false";
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				if (message.contains("L-")) {
					String eventType = message.split("-")[1];
					String s = sendRequest(8888, "L-" + eventType);
					if (eventType.equalsIgnoreCase("conference")) {
						replycon = Que.conferenceList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("seminar")) {
						replycon = Que.seminalList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						replycon = Que.tradeshowList.toString();
						System.out.println("List: "+replycon.toString());
					} else {
						replycon = "false";
					}
					replycon = replycon+" "+s;
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				if (message.contains("X-")) {
					String eventType = message.split("-")[1];
					if (eventType.equalsIgnoreCase("conference")) {
						replycon = Que.conferenceList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("seminar")) {
						replycon = Que.seminalList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						replycon = Que.tradeshowList.toString();
						System.out.println("List: "+replycon.toString());
					} else {
						replycon = "false";
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				if(message.contains("V")) {
					replycon = "";
					String customerId = message.split(" ")[1];
					String s = QuebecServer.sendRequest(8888, "V " + customerId);
					if (Que.eventBook.containsKey(customerId)) {
						for (int i = 0; i < Que.eventBook.get(customerId).size(); i++) {
							replycon += Que.eventBook.get(customerId).get(i).getEventId() + " "
									+ Que.eventBook.get(customerId).get(i).getEventType() + "\n";
					}
					}
					else {
						replycon = "";
					}
					replycon = replycon+s;
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}	
				if(message.contains("P")) {
					replycon = "";
					String customerId = message.split(" ")[1];
					if (Que.eventBook.containsKey(customerId)) {
						for (int i = 0; i < Que.eventBook.get(customerId).size(); i++) {
							replycon += Que.eventBook.get(customerId).get(i).getEventId() + " "
									+ Que.eventBook.get(customerId).get(i).getEventType() + "\n";
					}
					}
					else {
						replycon = "";
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}	

				mySocket.close();
			}
		} // end try
		catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public static void server() {
		LoggerFile log = new LoggerFile();
		Endpoint.publish("http://localhost:8081/quebec", Que);
		System.out.println("QUEBEC Server is Up & Running");
		log.logger.setLevel(Level.INFO);
		log.logger.info("QUEBEC Server is Up & Running");

	}

	public static String sendRequest(int port, String requests) {
		LoggerFile log = new LoggerFile();
		DatagramSocket aSocket = null;
		String list = null;
		try {
			aSocket = new DatagramSocket();
			InetAddress aHost = InetAddress.getByName("localhost");
			String req_msg = requests;
			byte[] message = new byte[1000];
			message = req_msg.trim().getBytes();
			DatagramPacket request = new DatagramPacket(message, message.length, aHost, port);
			log.logger.setLevel(Level.INFO);
			log.logger.info("Quebec Server sending this request " + message + " to server with port " + port);
			aSocket.send(request);
			byte[] buffer = new byte[1000];
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
			aSocket.receive(reply);
			String res = new String(reply.getData());
			list = res;
		} catch (Exception e) {
			System.out.println("Socket: " + e.getMessage());
		}
		return list;
	}

}
