package Replica2;


import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC)
public interface ServerInterface {
	@WebMethod
	public String addEvent(String managerId, String eventId, String eventType, int capacity);
	@WebMethod
	public String removeEvent(String managerId, String eventId, String eventType);
	@WebMethod
	public String listEventAvailability(String eventType);
	@WebMethod
	public String bookEvent(String customerId, String eventId,String eventType);
	@WebMethod
	public String cancelEvent(String customerId, String eventId, String evenType);
	@WebMethod
	public String getBookingSchedule(String customerId);
	@WebMethod
	public String swapEvent(String customerId, String newEventId, String newEventType, String oldEventId, String oldEventType);




}
