package Replica2;


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import javax.xml.ws.Endpoint;


import Entity.Event;
import Entity.LoggerFile;

public class ShebrookServer {

	public static ShebrookObj She;

	public static void main(String args[]){
		She = new ShebrookObj();
		Runnable task = () -> {
			UdpConnection();
		};
		Runnable task2 = () -> {
				server();
		};

		Thread thread = new Thread(task);
		Thread thread2 = new Thread(task2);

		thread.start();
		thread2.start();

	}

	public static void UdpConnection() {
		LoggerFile log = new LoggerFile();
		System.out.println("SHEBROOK UDP SERVER STARTED ON " + 8888);
		log.logger.setLevel(Level.INFO);
		log.logger.info("SHEBROOK UDP SERVER STARTED ON " + 8888);
		try {
			while (true) {
				DatagramSocket mySocket = new DatagramSocket(8888);
				DatagramPacket reply;

				// instantiates a datagram socket for receiving the data
				byte[] buffer = new byte[1000];
				DatagramPacket datagram = new DatagramPacket(buffer, buffer.length);
				mySocket.receive(datagram);
				String message = (new String(datagram.getData()).trim());
				System.out.println("message " + message);
				log.logger.setLevel(Level.INFO);
				log.logger.info("Shebrooke server received request "+message+ " from the server with port "+datagram.getPort());
				String replycon = "";
				if (message.contains(",")) {
					String customerId = message.split(",")[0];
					String eventId = message.split(",")[1];
					String eventType = message.split(",")[2];
					int check = She.findEvent(customerId, eventId);
					if (eventType.equalsIgnoreCase("conference")) {
						if (She.conferenceList.containsKey(eventId.toUpperCase())) {
							if (She.conferenceList.get(eventId.toUpperCase()) >= 1) {
								if (She.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = She.conferenceList.get(eventId.toUpperCase());
									caps -= 1;
									She.conferenceList.put(eventId.toUpperCase(), caps);
									She.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!She.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = She.conferenceList.get(eventId.toUpperCase());
									caps -= 1;
									She.conferenceList.put(eventId.toUpperCase(), caps);
									List<Event> add = new ArrayList<Event>();
									She.eventBook.put(customerId, add);
									She.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					} else if (eventType.equalsIgnoreCase("seminar")) {
						if (She.seminalList.containsKey(eventId.toUpperCase())) {
							if (She.seminalList.get(eventId.toUpperCase()) >= 1) {
								if (She.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = She.seminalList.get(eventId.toUpperCase());
									caps -= 1;
									She.seminalList.put(eventId.toUpperCase(), caps);
									She.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!She.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = She.seminalList.get(eventId.toUpperCase());
									caps -= 1;
									She.seminalList.put(eventId.toUpperCase(), caps);
									List<Event> add = new ArrayList<Event>();
									She.eventBook.put(customerId, add);
									She.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						if (She.tradeshowList.containsKey(eventId.toUpperCase())) {
							if (She.tradeshowList.get(eventId.toUpperCase()) >= 1) {
								if (She.eventBook.containsKey(customerId.toUpperCase()) && check == -1) {
									int caps = She.tradeshowList.get(eventId.toUpperCase());
									caps -= 1;
									She.tradeshowList.put(eventId.toUpperCase(), caps);
									She.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else if (!She.eventBook.containsKey(customerId.toUpperCase())) {
									int caps = She.tradeshowList.get(eventId.toUpperCase());
									caps -= 1;
									She.tradeshowList.put(eventId, caps);
									List<Event> add = new ArrayList<Event>();
									She.eventBook.put(customerId, add);
									She.eventBook.get(customerId.toUpperCase()).add(new Event(customerId.toUpperCase(),
											eventId.toUpperCase(), eventType.toUpperCase()));
									replycon = "true";
									log.logger.setLevel(Level.INFO);
									log.logger.info(customerId.toUpperCase()
											+ " successfully booked an event of event ID " + eventId.toUpperCase());
								} else {
									replycon = "false";
									log.logger.setLevel(Level.INFO);
									log.logger.info("Event booking by " + customerId.toUpperCase() + " of event ID "
											+ eventId.toUpperCase() + " was unsuccessfull ");
								}
							} else {
								replycon = "false";
								log.logger.setLevel(Level.INFO);
								log.logger.info("Booking of event with ID " + eventId.toUpperCase() + "for customer ID "
										+ customerId.toUpperCase() + " was unsuccessfull ");
							}
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking of event ID " + eventId + "does not exist, Failed!");
						}
					}

					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					log.logger.setLevel(Level.INFO);
					log.logger.info("Shebrooke Server sending back response " + replycon + " to Server with port "
							+ reply.getPort());
					mySocket.send(reply);
				}
				if (message.contains(":")) {
					String customerId = message.split(":")[0];
					String eventId = message.split(":")[1];
					String eventType = message.split(":")[2];
					int check = She.findEvent(customerId, eventId);
					if (eventType.equalsIgnoreCase("conference")) {
						if (She.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = She.findEvent(customerId, eventId);
							She.eventBook.get(customerId).remove(index);
							She.conferenceList.put(eventId.toUpperCase(),
									She.conferenceList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
									+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					} else if (eventType.equalsIgnoreCase("seminar")) {
						if (She.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = She.findEvent(customerId, eventId);
							She.eventBook.get(customerId).remove(index);
							She.seminalList.put(eventId.toUpperCase(), She.seminalList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
									+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						if (She.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
							int index = She.findEvent(customerId, eventId);
							She.eventBook.get(customerId).remove(index);
							She.tradeshowList.put(eventId.toUpperCase(),
									She.tradeshowList.get(eventId.toUpperCase()) + 1);
							replycon = "true";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booked by customer ID " + customerId.toUpperCase()
									+ " was cancelled successfully");
						} else {
							replycon = "false";
							log.logger.setLevel(Level.INFO);
							log.logger.info("Event booking cancellation was not succesfull because the event ID "
									+ eventId.toUpperCase() + " does not exist");
						}
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					log.logger.setLevel(Level.INFO);
					log.logger.info("Shebrooke Server sending back response " + replycon + " to Server with port "
							+ reply.getPort());
					mySocket.send(reply);

				}
				if (message.contains("Swap")) {
					String customerId = message.split(" ")[1];
					String newEventId = message.split(" ")[2];
					String newEventType = message.split(" ")[3];
					String oldEventId = message.split(" ")[4];
					String oldEventType = message.split(" ")[5];
					int check = She.findEvent(customerId, oldEventId);
					if (She.eventBook.containsKey(customerId.toUpperCase()) && check != -1) {
					replycon = She.bookEvent(customerId, newEventId, newEventType);	
					if(replycon.contains("Your")) {
					She.eventBook.get(customerId).remove(check);
					She.eventList.get(oldEventType.toUpperCase()).put(oldEventId.toUpperCase(), She.eventList.get(oldEventType.toUpperCase()).get(oldEventId.toUpperCase()) + 1);
					}
					}else {
						replycon = "false";
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				if (message.contains("L-")) {
					String eventType = message.split("-")[1];
					if (eventType.equalsIgnoreCase("conference")) {
						replycon = She.conferenceList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("seminar")) {
						replycon = She.seminalList.toString();
						System.out.println("List: "+replycon.toString());
					} else if (eventType.equalsIgnoreCase("tradeshow")) {
						replycon = She.tradeshowList.toString();
						System.out.println("List: "+replycon.toString());
					} else {
						replycon = "false";
					}
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}
				if(message.contains("V")) {
					replycon = "";
					String customerId = message.split(" ")[1];
					if (She.eventBook.containsKey(customerId)) {
						for (int i = 0; i < She.eventBook.get(customerId).size(); i++) {
							replycon += She.eventBook.get(customerId).get(i).getEventId() + " "
									+ She.eventBook.get(customerId).get(i).getEventType() + "\n";
						}
					}else {
						replycon = "";
					}
					//replycon = list;
					byte[] reply_con = replycon.getBytes();
					reply = new DatagramPacket(reply_con, reply_con.length, datagram.getAddress(), datagram.getPort());
					mySocket.send(reply);
				}	
				mySocket.close();
			}
		} // end try
		catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public static void server() {
		LoggerFile log = new LoggerFile();
		Endpoint.publish("http://localhost:8082/shebrook", She);
		System.out.println("SHEBROOKE Server is Up & Running");
		log.logger.setLevel(Level.INFO);
		log.logger.info("SHEBROOKE Server is Up");
	}

	public static String sendRequest(int port, String requests) {
		LoggerFile log = new LoggerFile();
		DatagramSocket aSocket = null;
		String list = null;
		try {
			aSocket = new DatagramSocket();
			InetAddress aHost = InetAddress.getByName("localhost");
			String req_msg = requests;
			byte[] message = new byte[1000];
			message = req_msg.trim().getBytes();
			DatagramPacket request = new DatagramPacket(message, message.length, aHost, port);
			log.logger.info("Shebrooke Server sending this request " + message + " to server with port " + port);
			aSocket.send(request);
			byte[] buffer = new byte[1000];
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
			aSocket.receive(reply);
			String res = new String(reply.getData());
			list = res;

		} catch (Exception e) {
			System.out.println("Socket: " + e.getMessage());
		}
		return list;
	}

}
